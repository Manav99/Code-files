# Define the UI for the app
library(shiny)
library(shinydashboard)
library(rmarkdown)

# Define the UI for the app
ui <- dashboardPage(
  dashboardHeader(
    title = tags$a(href='',
                   tags$img(src='CCRB_logo.png', height = 60, width = 60)),
    titleWidth = 229
  ),
  dashboardSidebar(
    textInput("po_name_input", "Enter PO Name", value = ""),
    dateInput("date_input", "Select Date", value = Sys.Date()),
    checkboxGroupInput("report_type", "Select Report Types:",
                       choices = c("Vehicle Stop Reports" = "vehicle",
                                   "VTL/B Summonses" = "vtl",
                                   "C Summonses" = "criminal")),
    actionButton("generate_report", "Generate Report"),
    div(style = "position: absolute; bottom: 0; width: 100%;",
        fluidRow(
          column(12, 
                 tags$footer(class = "footer", 
                             style = " line-height: 60px; text-align: center;",
                             icon("copyright"), "Data Science Team, RPBP Unit"
                 )
          )
        )
    )
  ),
  dashboardBody(
    tags$head(
      tags$link(rel = "icon", type = "image/png", sizes = "32x32", href = "www/CCRB_logo.png"),
      tags$style(".main-header {max-height: 60px}"),
      tags$style(".main-header .logo {height: 60px;}"),
      tags$style(".sidebar-toggle {height: 60px; padding-top: 1px !important;}"),
      tags$style(".navbar {min-height:60px !important}")
    ),
    # Output for the HTML report
    htmlOutput("report_ui"),
    # Download button for the Word report
    # fluidRow(
    #   column(12, 
    #          div(style = "text-align: right;",  # Align the button to the right
    #              downloadButton("download_report", "Download Report")
    #          )
    #   )
    # )
    # Footer
    # fluidRow(
    #   column(12, 
    #          tags$footer(class = "footer", 
    #                      style = "width: 100%; background-color: #f5f5f5; line-height: 60px; text-align: center;",
    #                      icon("copyright"), " 2023 Designed and developed by Data Science Team, RPBP Unit, CCRB"
    #          )
    #   )
    # )
  )
)

server <- function(input, output, session) {
  # Reactive value to store the path of the Word report
  word_report_path <- reactiveVal(NULL)
  
  observeEvent(input$generate_report, {
    # Calculate the through_date as 365 days before the from_date
    through_date <- as.Date(input$date_input) - 365
    
    # Generate a unique ID for each report to prevent caching issues
    report_id <- format(Sys.time(), "%Y%m%d-%H%M%OS")
    html_file_name <- paste0("report-", report_id, ".html")
    
    # Define the path for the HTML report
    html_report_path <- file.path("www", html_file_name)
    
    # Render the report in HTML format and save to the www directory
    rmarkdown::render("data_report_template.Rmd", output_file = html_report_path, params = list(
      po_name = input$po_name_input,
      from_date = input$date_input,
      through_date = through_date,
      report_type = input$report_type  # Pass the selected report types to the Rmd
    ), output_format = "html_document")
    
    # Store the file name in the reactive value for the Word report
    word_report_path(file.path("www", paste0("report-", report_id, ".docx")))
    
    # Display the HTML report in the Shiny app
    output$report_ui <- renderUI({
      tags$iframe(style = "height:600px; width:100%; border: none;", src = html_file_name)
    })
  })
  
  # Set up the download handler for the Word document
  output$download_report <- downloadHandler(
    filename = function() {
      paste0("vehicle_report-", Sys.Date(), ".docx")
    },
    content = function(file) {
      req(word_report_path())  # Ensure the path is available
      
      # Copy the Word report to the download path
      file.copy(word_report_path(), file)
    }
  )
}

shinyApp(ui, server)
